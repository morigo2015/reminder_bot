"""
Centralized configuration for the Reminder Bot.
"""

from dotenv import load_dotenv

# load .env if present
load_dotenv()

BOT_TOKEN = "550433191:AAFkG6atLs_uo0nwphtuiwbwIJeUhwfzCyI"
NURSE_CHAT_ID = 7391874317  # ks
