This folder intentionally left blank to host logs at runtime.
