from apscheduler.schedulers.asyncio import AsyncIOScheduler

def create_scheduler():
    return AsyncIOScheduler()
