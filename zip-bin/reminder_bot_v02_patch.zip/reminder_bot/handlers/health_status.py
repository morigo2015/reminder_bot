from aiogram import Router
from aiogram.filters import Text
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from reminder_bot.states import ReminderStates

router = Router()
STATUS_COMMANDS = ['/status', 'звіт', 'report']

@router.message(ReminderStates.collecting_status, Text(startswith=tuple(STATUS_COMMANDS), ignore_case=True))
async def status_handler(message: Message, state: FSMContext):
    # Implementation for windowed collection...
    await message.answer('📝 Status recorded.')
