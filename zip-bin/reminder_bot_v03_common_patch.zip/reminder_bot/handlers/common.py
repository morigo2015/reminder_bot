from aiogram import Router

router = Router()
# Common handler deprecated: individual FSM-based handlers are used instead.
