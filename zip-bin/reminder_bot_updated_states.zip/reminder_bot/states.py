from aiogram.fsm.state import StatesGroup, State

class ReminderStates(StatesGroup):
    waiting_confirmation = State()
    waiting_clarification = State()

class StatusStates(StatesGroup):
    waiting_status = State()
