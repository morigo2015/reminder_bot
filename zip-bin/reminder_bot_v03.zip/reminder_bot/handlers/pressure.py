import re
from aiogram import Router
from aiogram.filters import Command, Regexp
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from reminder_bot.states import ReminderStates

router = Router()

PRESSURE_COMMANDS = ['pressure', 'тиск']

@router.message(Command(['pressure','bp']))
async def pressure_entry(message: Message, state: FSMContext):
    """User initiates blood-pressure entry. Sets FSM to entering_pressure."""
    await message.answer('Введіть три числа: систолічний, діастолічний, пульс, наприклад: тиск 120 80 70')
    await state.set_state(ReminderStates.entering_pressure)

PRESSURE_PATTERN = r'^(?:тиск|pressure)\s+(\d{1,3})\s+(\d{1,3})\s+(\d{1,3})$'

@router.message(ReminderStates.entering_pressure, Regexp(PRESSURE_PATTERN, flags=re.IGNORECASE))
async def pressure_handler(message: Message, regexp: re.Match, state: FSMContext):
    """Handles blood-pressure input when in entering_pressure state."""
    high, low, pulse = map(int, regexp.groups())
    log_service = message.bot['log_service']
    await log_service.pressure(message.chat.id, high, low, pulse)
    await message.answer(f'📋 Logged pressure: {high}/{low}, pulse {pulse}')
    await state.clear()
