import re
from aiogram import Router
from aiogram.filters import Regexp
from aiogram.types import Message
from aiogram.fsm.context import FSMContext

from reminder_bot.states import ReminderStates

router = Router()

OK_PATTERN = r'^(?:ok|так|yes|si|sure|👍)$'

@router.message(ReminderStates.waiting_confirmation, Regexp(OK_PATTERN, flags=re.IGNORECASE))
async def handle_confirmation(message: Message, regexp: re.Match, state: FSMContext):
    """Handles user confirmation for a reminder."""
    data = await state.get_data()
    event = data.get('current_event')
    # mark confirmed, cancel retry job via manager
    manager = message.bot['reminder_manager']
    await manager.cancel_flow(event, message.chat.id)
    await message.answer('✅ Confirmed.')
    await state.clear()

@router.message(ReminderStates.waiting_clarification, Regexp(OK_PATTERN, flags=re.IGNORECASE))
async def handle_clarification(message: Message, regexp: re.Match, state: FSMContext):
    """Handles user clarification for a reminder after retries exhausted."""
    data = await state.get_data()
    event = data.get('current_event')
    manager = message.bot['reminder_manager']
    await manager.finalize_flow(event, message.chat.id)
    await message.answer('✅ Clarification received.')
    await state.clear()
