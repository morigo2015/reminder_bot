from aiogram import Router
from aiogram.filters import Regex
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
import re

from reminder_bot.states import ReminderStates

router = Router()

OK_PATTERN = r'^(?:ok|так|yes|si|sure|👍)$'

@router.message(ReminderStates.waiting_confirmation, Regex(OK_PATTERN, flags=re.IGNORECASE))
async def handle_confirmation(message: Message, state: FSMContext):
    data = await state.get_data()
    event = data.get('current_event')
    await message.answer('✅ Confirmed.')
    # TODO: cancel retry job via reminder_manager
    await state.clear()

@router.message(ReminderStates.waiting_clarification, Regex(OK_PATTERN, flags=re.IGNORECASE))
async def handle_clarification(message: Message, state: FSMContext):
    await message.answer('✅ Thanks, clarification received.')
    # TODO: finalize flow
    await state.clear()
