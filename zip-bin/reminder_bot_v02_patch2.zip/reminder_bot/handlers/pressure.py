from aiogram import Router
from aiogram.filters import Regexp
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from reminder_bot.states import ReminderStates

router = Router()

PRESSURE_PATTERN = r'^(?:тиск|pressure)\s+(\d{1,3})\s+(\d{1,3})\s+(\d{1,3})$'

@router.message(ReminderStates.entering_pressure, Regexp(PRESSURE_PATTERN, flags=re.IGNORECASE))
async def pressure_handler(message: Message, regexp: Regexp, state: FSMContext):
    high, low, pulse = map(int, regexp.captures)
    log_service = state.bot['log_service']
    await log_service.pressure(message.chat.id, high, low, pulse)
    await message.answer(f'📋 Logged pressure: {high}/{low}, pulse {pulse}')
    await state.clear()
