from aiogram.fsm.state import StatesGroup, State

class ReminderFlow(StatesGroup):
    waiting_ok = State()
    waiting_clarification = State()

class StatusFlow(StatesGroup):
    waiting_status = State()
